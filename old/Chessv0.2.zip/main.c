#include <stdio.h>
#include "./src/board.c"
#include "./src/eval.c"
#include "./src/movegen.c"
#include "./src/search.c"

int main()
{
    struct Move move; // Variable to store move
    
    new_game();
    print_board();

    for (int i = 0; i < 50; i++) {
        
        nodes_searched = 0;
        quiet_nodes_searched = 0;
        
        move = get_move(5); // Calculate best move
        
        // Log some data
        
        // Make move and print
        make_move(move);
        print_board();
    }

    return 0;

}