#include "./include/search.h"

// Compares two moves based on their score and returns an integer value
int compare_moves(const void *move_1, const void *move_2)
{
    struct Move m1 = *((struct Move*)move_1);
    struct Move m2 = *((struct Move*)move_2);
    return -(m1.score - m2.score);
}

// Sorts moves from highest score to lowest score
void sort_moves(void *move_list, int items)
{
    qsort(move_list, items, sizeof(struct Move), compare_moves);
}

// Ranks captures based on the value of piece attacking and the value of capture
int lva_mvv(const void *move_1, const void *move_2)
{
    struct Move m1 = *((struct Move*)move_1);
    struct Move m2 = *((struct Move*)move_2);
    return -((m1.capture % 6 - m1.piece % 6) - (m2.capture % 6 - m2.piece % 6));
}

// Sorts moves based on the capture value and the piece value
void sort_tactical_moves(void *move_list, int items)
{
    qsort(move_list, items, sizeof(struct Move), lva_mvv);
}

// Finds the best move in any position to a fixed depth
struct Move get_move(unsigned int depth)
{
    unsigned int search_depth = 2;
    unsigned int index;
    
    struct MoveList move_stack[128];
    
    
    struct MoveList moves;
    struct Move best_move;
    
    int alpha, beta;
    int best_score, score;
    
    gen_movegen(&moves, &moves);
    
    // Creates initial scores for move ordering purposes for every move
    for (int i = 0; i < moves.num; i++) {
        if (cboard.board[moves.list[i].to] % 6 == KI)
            moves.list[i].score = 100000;
        make_move(moves.list[i]);
        moves.list[i].score = -quiesce(100000, -100000);
        undo_move(moves.list[i]);
    }
    
    sort_moves(moves.list, moves.num);
    
    while (search_depth <= depth) {
        index = 1;
        
        while (index < search_depth) {
        // Resets values for each new iteration
        best_score = -100000;
        alpha = -100000;
        beta = 100000;
        
        
        // Test and evaluates all moves
        for (int i = 0; i < moves.num; i++) {
            if (cboard.board[moves.list[i].to] % 6 == KI)
                return moves.list[i];
            
            make_move(moves.list[i]);
            
            score = -alpha_beta(-beta, -alpha, search_depth - 1);
            
            moves.list[i].score = score;
            
            alpha = max(score, alpha);
            
            if (score > best_score) {
                best_score = score;
                best_move = moves.list[i];
            }
        
            undo_move(moves.list[i]);
        }
        }
        
        // Resets values for each new iteration
        best_score = -100000;
        alpha = -100000;
        beta = 100000;
        
        
        // Test and evaluates all moves
        for (int i = 0; i < moves.num; i++) {
            if (cboard.board[moves.list[i].to] % 6 == KI)
                return moves.list[i];
            
            make_move(moves.list[i]);
            
            score = -alpha_beta(-beta, -alpha, search_depth - 1);
            
            moves.list[i].score = score;
            
            alpha = max(score, alpha);
            
            if (score > best_score) {
                best_score = score;
                best_move = moves.list[i];
            }
        
            undo_move(moves.list[i]);
        }
        search_depth++;
        
        sort_moves(moves.list, moves.num);
    }
    
    return best_move;
}

int alpha_beta(int alpha, int beta, unsigned int depth)
{
    nodes_searched++;
    if (depth == 0)
        return quiesce(alpha, beta); // Returns evaluation at end of search
    
    struct MoveList moves;
    int score = -100000;
    
    gen_movegen(&moves, &moves);
    
    // Stalemate if no moves remain
    if (moves.num == 0)
        return 0;
    
    // Perform IID only at high depths
    if (depth > 5) {
        for (int i = 0; i < moves.num; i++) {
            if (cboard.board[moves.list[i].to] % 6 == KI)
                return 100000;
            make_move(moves.list[i]);
            moves.list[i].score = -alpha_beta(-beta, -alpha, depth / 4);
            undo_move(moves.list[i]);
        }
        
        sort_moves(moves.list, moves.num);
    }
    
    // Test and evaluate all moves
    for (int i = 0; i < moves.num; i++) {
        if (cboard.board[moves.list[i].to] % 6 == KI)
            return 100000;
        
        make_move(moves.list[i]);
        
        score = max(score, -alpha_beta(-beta, -alpha, depth - 1));
        
        undo_move(moves.list[i]);
        
        alpha = max(score, alpha);
        if (alpha >= beta)
            return score;
    }

    return score;
}

int quiesce(int alpha, int beta)
{
    quiet_nodes_searched++;
    int stand_pat = evaluate();
    int score;
    
    // Stop searching if the current position is already the best
    if (stand_pat >= beta)
        return stand_pat;
        
    // Stop searching if this line will never lead to a good outcome
    if (stand_pat <= alpha - 200)
        return stand_pat;

    alpha = max(alpha, stand_pat);

    struct MoveList ta_moves, qu_moves;
    gen_movegen(&ta_moves, &qu_moves);
    
    sort_tactical_moves(ta_moves.list, ta_moves.num);
    
    // Test and return evaluations for all moves
    for (int i = 0; i < ta_moves.num; i++) {
        if (cboard.board[ta_moves.list[i].to] % 6 == KI)
            return 100000;
            
        make_move(ta_moves.list[i]);
        
        score = -quiesce(-beta, -alpha);
        
        undo_move(ta_moves.list[i]);
        
        alpha = max(score, alpha);
        
        if (score >= beta)
            return score;
    }
    
    return alpha;
}