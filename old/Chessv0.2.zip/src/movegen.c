#include "./include/movegen.h"

void gen_movegen(struct MoveList *ta_moves, struct MoveList *qu_moves)
{
    ta_moves->num = 0;
    qu_moves->num = 0;
    
    // For every square on the board, computes all moves
    for (int sq = 20; sq < 100; sq++) {
        // Don't generate moves if it's not your piece
        if (!is_friendly(sq))
            continue;
            
        // Use different move generation algorithm depending on the type
        switch (cboard.board[sq] % 6) {
            case PA:
            sgl_pawnmv(qu_moves, sq);
            dbl_pawnmv(qu_moves, sq);
            cap_pawnmv(ta_moves, sq);
            break;
            
            case KN:
            knight_mv(ta_moves, qu_moves, sq);
            break;
            
            case BI:
            diag_mv(ta_moves, qu_moves, sq);
            break;
            
            case RO:
            orth_mv(ta_moves, qu_moves, sq);
            break;
            
            case QU:
            diag_mv(ta_moves, qu_moves, sq);
            orth_mv(ta_moves, qu_moves, sq);
            break;
            
            case KI:
            king_mv(ta_moves, qu_moves, sq);
            break;
        }
    }
}

void sliding_mv(
    struct MoveList *ta_moves,
    struct MoveList *qu_moves,
    Square sq, int *dir)
{
    Square target = sq;
    
    // Uses a blocker loop to generate sliding moves
    for (int i = 0; i < 4; i++) {
        target = sq + dir[i];
        
        // As long as the squares are empty, it's a valid move
        while (cboard.board[target] == EM) {
            append_move(qu_moves, cboard.turn, 0, QUIET,
                sq, target, cboard.board[sq], cboard.board[target]);
            target += dir[i];
        }
        // Specifically add a cpture if there is an enemy piece at the end
        if (is_enemy(target))
            append_move(ta_moves, cboard.turn, 0, CAPT,
                sq, target, cboard.board[sq], cboard.board[target]);
    }
}

// Uses sliding move function to generate rook/queen moves
void orth_mv(struct MoveList *ta_moves, struct MoveList *qu_moves, Square sq)
{
    int dir[4] = {NO, EA, SO, WE};
    sliding_mv(ta_moves, qu_moves, sq, dir);
}

// Uses sliding move function to generate bishop/queen moves
void diag_mv(struct MoveList *ta_moves, struct MoveList *qu_moves, Square sq)
{
    int dir[4] = {NE, NW, SE, SW};
    
    sliding_mv(ta_moves, qu_moves, sq, dir);
}

void king_mv(struct MoveList *ta_moves, struct MoveList *qu_moves, Square sq)
{
    int dir[8] = {NO, EA, SO, WE, NE, NW, SE, SW};
    Square target;
    
    // Tests all squares of distance one and deals with them accordingly
    for (int i = 0; i < 8; i++) {
        target = sq + dir[i];
        if (cboard.board[target] == EM)
            append_move(qu_moves, cboard.turn, 0, QUIET,
                sq, target, cboard.board[sq], cboard.board[target]);
        if (is_enemy(target))
            append_move(ta_moves, cboard.turn, 0, CAPT,
                sq, target, cboard.board[sq], cboard.board[target]);
    }
}

void knight_mv(struct MoveList *ta_moves, struct MoveList *qu_moves, Square sq)
{
    int dir[8] = {NNE, NNW, SSE, SSW, NEE, NWW, SEE, SWW};
    Square target;
    
    // Tests all pseudolegal knight moves and deals with them accordingly
    for (int i = 0; i < 8; i++) {
        target = sq + dir[i];
        if (cboard.board[target] == EM)
            append_move(qu_moves, cboard.turn, 0, QUIET,
                sq, target, cboard.board[sq], cboard.board[target]);
        if (is_enemy(target))
            append_move(ta_moves, cboard.turn, 0, CAPT,
                sq, target, cboard.board[sq], cboard.board[target]);
    }
}

void sgl_pawnmv(struct MoveList *qu_moves, Square sq)
{
    int dir = (cboard.turn) ? NO : SO;
    Square target = sq + dir;
    
    // Checks if the space ahead of the pawn is empty
    if (cboard.board[target] == EM)
        append_move(qu_moves, cboard.turn, 0, QUIET,
            sq, target, cboard.board[sq], cboard.board[target]);
}

void dbl_pawnmv(struct MoveList *qu_moves, Square sq)
{
    int dir = (cboard.turn) ? NO : SO;
    int rank = (cboard.turn) ? 80 : 30;
    Square target = sq + 2*dir;
    
    // Checks if the pawn is on the home rank and has space in front of it
    if (sq < rank || rank + 10 < sq )
        return;
    if (cboard.board[sq + dir] != EM)
        return;
    
    if (cboard.board[target] == EM)
        append_move(qu_moves, cboard.turn, 0, DBL_PA_PSH,
            sq, target, cboard.board[sq], cboard.board[target]);
}

void cap_pawnmv(struct MoveList *ta_moves, Square sq)
{
    int dir[2];
    Square target;
    
    // Initializes capture directions based on B/W pawn
    if (cboard.turn == W) {
        dir[0] = NE;
        dir[1] = NW;
    } else {
        dir[0] = SE;
        dir[1] = SW;
    }
    
    for (int i = 0; i < 2; i++) {
        target = sq + dir[i];
        if (is_enemy(target)) {
            append_move(ta_moves, cboard.turn, 0, CAPT,
                sq, target, cboard.board[sq], cboard.board[target]);
        }
    }
}

// Creates a move structure and appends it to a move list
void append_move(
    struct MoveList *mv_list,
    uint8_t turn, int score,
    uint8_t type,
    Square from,
    Square to,
    Piece piece,
    Piece capture)
{
    struct Move move = {
        .turn = turn,
        .score = score,
        .type = type,
        .from = from,
        .to = to,
        .piece = piece,
        .capture = capture
    };

    mv_list->list[mv_list->num] = move;
    mv_list->num++;
}