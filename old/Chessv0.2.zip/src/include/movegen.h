#ifndef MOVEGEN_H
#define MOVEGEN_H

#include "eval.h"
#include "board.h"
#include "types.h"

void gen_movegen(struct MoveList *ta_moves, struct MoveList *qu_moves);

void sliding_mv(
    struct MoveList *ta_moves,
    struct MoveList *qu_moves,
    Square sq, int *dir);

void orth_mv(struct MoveList *ta_moves, struct MoveList *qu_moves, Square sq);

void diag_mv(struct MoveList *ta_moves, struct MoveList *qu_moves, Square sq);

void king_mv(struct MoveList *ta_moves, struct MoveList *qu_moves, Square sq);

void knight_mv(struct MoveList *ta_moves, struct MoveList *qu_moves, Square sq);

void sgl_pawnmv(struct MoveList *qu_moves, Square sq);

void dbl_pawnmv(struct MoveList *qu_moves, Square sq);

void cap_pawnmv(struct MoveList *ta_moves, Square sq);

void append_move(
    struct MoveList *mv_list,
    uint8_t turn, int score,
    uint8_t type,
    Square from,
    Square to,
    Piece piece,
    Piece capture);
#endif