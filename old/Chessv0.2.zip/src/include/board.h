#ifndef BOARD_H
#define BOARD_H

#include "types.h"

extern struct Board cboard;


char *algebraic(struct Move move, char *string);

bool is_mate();
int threats(Square sq);

void print_move(struct Move move);

void print_board();

bool is_enemy(Square sq);

bool is_friendly(Square sq);

void make_move(struct Move move);

void undo_move(struct Move move);

#endif