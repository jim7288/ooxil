#ifndef TYPES_H
#define TYPES_H

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include <limits.h>
#include <float.h>
#include <string.h>

#define MAX_SEARCH_DEPTH 1000
#define IV_SQUARE 255

extern int quiet_nodes_searched;
extern int nodes_searched;

enum Turns {
    B, W
};

// Creates enumeration values for easy piece indexing
enum PieceIndex {
    PA, KN, BI, RO, QU, KI
};

// Enumerates directions on a chess board
enum Direction {
    NO = -10, EA = 1, SO = 10, WE = -1,
    NE = -9, SE = 11, NW = -11, SW = 9,
    NNE = -19, NEE = -8, SEE = 12, SSE = 21,
    SSW = 19, SWW = 8, NWW = -12, NNW = -21
};

// Enumerates piece codes
enum PieceValue {
    WP, WN, WB, WR, WQ, WK,
    BP, BN, BB, BR, BQ, BK,
    EM = 98, IV = 99
};

// Encodes move types as integers
enum MoveType {
    QUIET, // 0
    KS_CASTLE, // 1
    QS_CASTLE, // 2
    DBL_PA_PSH, // 3
    CAPT, // 4
    EP_CAPT, // 5
    KN_PRM, BI_PRM,
    RO_PRM, QU_PRM,
    KN_CAPT_PRM, BI_CAPT_PRM,
    RO_CAPT_PRM, QU_CAPT_PRM
};

// Creates aliases for various types
typedef uint8_t Piece;
typedef uint8_t Square;
typedef uint32_t Move;

// Defines the format of a move
struct Move {
    uint8_t turn;
    int score;
    
    uint8_t type;
    
    Square from;
    Square to;
    
    Piece piece;
    Piece capture;
};

// Defines the array used for move storage
struct MoveList {
    int num;
    struct Move list[256];
};

// Defines the board representation
struct Board {
    uint8_t fifty_move_counter;
    uint8_t move_count;
    Square ep_square;
    bool castling_rights[2][2];
    bool time_remaining;
    
    enum PieceValue board[120];
    Square king[2];
    
    enum Turns turn;
};

#endif